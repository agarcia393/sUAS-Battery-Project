function [xwind, ywind, zwind]= windspeed(x,y,z)
%%% Set up wind speed [m/s] for (x,y,z) in that order 
xwind=x;
ywind=y;
zwind=z;
end
