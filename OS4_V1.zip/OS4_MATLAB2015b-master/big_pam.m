%%% Master Pramenter Control %%%%
%::::::::::::::::::::::::::::::;
%%% Static--Wind Speed Inputs 
%%%%%%%%%%%%%%%%%%%%  %%%%%%%%%%%%%%%%%%%%%
% Upper Limit Wind Speed(Saturation Block) 
[xwind_u, ywind_u, zwind_u]= windspeed(0,0,0); 
% Lower Limit Wind Speed(Saturation Block
[xwind_l, ywind_l, zwind_l]= windspeed(-3.2,0,0);
 % rate of speen incrases to final value 
[rate_x,rate_y,rate_z]= windspeed(-0.5,0,0); % Must repersent direction of wind (+ or -)
% Time when slop starts (sec)
[xt_start,yt_start,zt_start]=windspeed(5,0,0);

windmatreiz= [xwind_u, ywind_u, zwind_u;xwind_l,ywind_l,zwind_l];

%::::::::::::::::::::::::::::::

%%% Wind Speed Inputs 
wind_env=switching('off');
wind_state=switching('off');

%::::::::::::::::::::::::::::::;
%%% Waypoins 
Waypont=[ 20 20 20 0 ; 0 0 0 0]; % [x,y,z,yaw]
%%% Lookahead distance along the path
Lookah_distance=40; %[m]